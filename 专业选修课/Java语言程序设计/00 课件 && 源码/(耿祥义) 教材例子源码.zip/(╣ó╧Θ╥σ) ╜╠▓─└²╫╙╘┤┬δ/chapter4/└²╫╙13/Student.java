public class Student { 
   double computerArea(Circle c) {
      double area=c.getArea();
      return area; 
   } 
   double computerArea(Tixing t) {
      double area=t.getArea();
      return area; 
   } 
}

