package moon.star;
public class TestOne{
    public void fTestOne(){
        System.out.println("I am a method In TestOne class");
    }
}