package moon.star;
public class TestTwo{
    public void fTestTwo(){
        System.out.println("I am a method In TestTwo class");
    }
}