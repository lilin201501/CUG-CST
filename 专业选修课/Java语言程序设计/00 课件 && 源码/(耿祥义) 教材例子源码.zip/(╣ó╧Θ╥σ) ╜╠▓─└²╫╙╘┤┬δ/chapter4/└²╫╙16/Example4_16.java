import java.util.Date;
public class Example4_16 {
    public static void main(String args[]) {
       Date date=new Date();
       System.out.println("���ػ�����ʱ��:"); 
       System.out.println(date.toString());   
    }
}



