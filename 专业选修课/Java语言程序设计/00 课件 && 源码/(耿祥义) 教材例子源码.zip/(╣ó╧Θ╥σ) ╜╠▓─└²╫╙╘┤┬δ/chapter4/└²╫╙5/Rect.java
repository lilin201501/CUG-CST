public class Rect 
{
   double width;  //���εĿ� 
   double height; //���εĸ�
   double getArea() 
   {
      double area=width*height;
      return area;
   }
}