import moon.star.*;
public class Use{
   public static void main(String arg[] ){
       TestOne a=new TestOne();
       a.fTestOne();
       TestTwo b=new TestTwo();
       b.fTestTwo();
   }
}