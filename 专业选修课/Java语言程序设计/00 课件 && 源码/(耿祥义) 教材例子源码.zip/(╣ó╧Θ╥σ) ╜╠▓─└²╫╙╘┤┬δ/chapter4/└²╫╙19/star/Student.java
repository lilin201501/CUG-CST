package star;
public class Student {
    public int age;
    public void setAge(int age) {
      if(age>=7&&age<=28) {
          this.age=age;
      }
   }
   public int getAge() {
      return age;
   }

   public static void main(String arg[]){
      Student stu=new Student();
      stu.age=18;
      System.out.println("my age is"+stu.age);
   }
}




