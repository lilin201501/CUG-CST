import java.io.*;
public class Example10_4 {
   public static void main(String args[]) {
      int n=-1;
      byte [] a=new byte[100];
      try{  File f=new File("Example10_4.java");
            InputStream in = new FileInputStream(f);
            while((n=in.read(a,0,10))!=-1) {
               //System.out.println(n);
               String s=new String (a,0,10);
               System.out.println(s);
               System.out.println("-------------------------------");
            }
            in.close();
      }
      catch(IOException e) {
           System.out.println("File read Error"+e);
      }
   }
}


