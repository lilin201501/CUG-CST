public class Example10_21 {
   public static void main(String args[]) {
      new CommFrame();
   }
}
