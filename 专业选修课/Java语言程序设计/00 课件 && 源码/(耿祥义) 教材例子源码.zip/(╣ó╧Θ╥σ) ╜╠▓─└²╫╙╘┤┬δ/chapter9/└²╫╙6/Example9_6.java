public class Example9_6 {
   public static void main(String args[]) {
      WindowActionEvent win=new WindowActionEvent();
      win.setTitle("����ActionEvent�¼�");
      win.setBounds(100,100,310,260);
   }
}
