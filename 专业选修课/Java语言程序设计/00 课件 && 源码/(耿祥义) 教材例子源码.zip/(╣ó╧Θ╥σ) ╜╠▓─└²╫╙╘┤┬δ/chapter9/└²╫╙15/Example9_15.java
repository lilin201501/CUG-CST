public class Example9_15 {
   public static void main(String args[]){
      WindowTriangle win=new WindowTriangle();
      win.setTitle("ʹ��MVC�ṹ"); 
      win.setBounds(100,100,420,260);
   }
}


