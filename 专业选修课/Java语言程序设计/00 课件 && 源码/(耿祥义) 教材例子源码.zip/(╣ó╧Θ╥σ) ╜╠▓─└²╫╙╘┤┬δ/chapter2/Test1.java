public class Test1 {

    public static void main(String[] args) {

        char A='\'',B='\"',C='\\',D='\u4F80';
        
        System.out.println(A);

        System.out.println(B);
        
        System.out.println(C);

        System.out.println(D);

        System.out.println("��һ��\t��һ��");

        System.out.println((char)12358);

        System.out.println((int)'A');
    }

}

