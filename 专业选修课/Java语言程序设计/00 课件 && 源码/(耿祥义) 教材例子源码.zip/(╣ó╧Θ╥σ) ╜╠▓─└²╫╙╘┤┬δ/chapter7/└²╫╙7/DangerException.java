public class DangerException extends Exception {
   final String message = "����";
   public String warnMess() {
       return message;
   }
} 
