abstract class OutputAlphabet {
   public abstract void output();
}


