public class Example12_6 {
   public static void main(String args[]) {
      ClassRoom room6501=new ClassRoom();
      room6501.student.start();
      room6501.teacher.start();
   }
}
