public class Example12_11 {
   public static void main(String args[]) {
      Win win=new Win();
   }
}
