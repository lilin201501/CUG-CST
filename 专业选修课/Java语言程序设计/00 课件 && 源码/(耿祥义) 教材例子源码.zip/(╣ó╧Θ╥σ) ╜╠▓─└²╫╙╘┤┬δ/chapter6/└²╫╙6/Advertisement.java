public interface Advertisement { //�ӿ�
      public void showAdvertisement();
      public String getCorpName();
}
