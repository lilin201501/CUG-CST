public class Japan implements Computable { //Japan��ʵ��Computable�ӿ�
   int number;
   public int f(int x) {
      return MAX+x; 
   }
}
