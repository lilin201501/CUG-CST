public class Example14_4 {
   public static void main(String args[]) {
      javax.swing.JFrame win = new javax.swing.JFrame();
      win.setSize(400,400);
      win.add(new Clock());
      win.setVisible(true);    
   }     
}