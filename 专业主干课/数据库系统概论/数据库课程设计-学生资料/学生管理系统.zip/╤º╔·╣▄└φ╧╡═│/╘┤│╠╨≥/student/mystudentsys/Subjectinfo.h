#if !defined(AFX_SUBJECTINFO_H__D81C7947_3788_44AB_A6CC_FD2917C0AAE2__INCLUDED_)
#define AFX_SUBJECTINFO_H__D81C7947_3788_44AB_A6CC_FD2917C0AAE2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Subjectinfo.h : header file
//
#include"afxdb.h"
/////////////////////////////////////////////////////////////////////////////
// CSubjectinfo recordset

class CSubjectinfo : public CRecordset
{
public:
	CSubjectinfo(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CSubjectinfo)

// Field/Param Data
	//{{AFX_FIELD(CSubjectinfo, CRecordset)
	CString	m_subject;
	CString	m_code;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSubjectinfo)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUBJECTINFO_H__D81C7947_3788_44AB_A6CC_FD2917C0AAE2__INCLUDED_)
