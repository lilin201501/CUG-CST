// mystudentsysDlg.h : header file
//

#if !defined(AFX_MYSTUDENTSYSDLG_H__CCE285FD_DAFC_41B6_A174_1A2D9E4A14EE__INCLUDED_)
#define AFX_MYSTUDENTSYSDLG_H__CCE285FD_DAFC_41B6_A174_1A2D9E4A14EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Subjectdlg.h"
#include "Grade_levelinfodlg.h"
#include "InfoStudent.h"
#include "Examinfo_submarkdlg.h"
#include "Regbreak_finddlg.h"

/////////////////////////////////////////////////////////////////////////////
// CMystudentsysDlg dialog

class CMystudentsysDlg : public CDialog
{
// Construction
public:
	CMystudentsysDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMystudentsysDlg)
	enum { IDD = IDD_MYSTUDENTSYS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMystudentsysDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMystudentsysDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAbout();
	afx_msg void OnMENUclassinfo();
	afx_msg void OnMENUclasssubject();
	afx_msg void OnMENUexamkind();
	afx_msg void OnMENUexit();
	afx_msg void OnMENUfindbreakinfo();
	afx_msg void OnMENUgradeleveldlg();
	afx_msg void OnMENUhelp();
	afx_msg void OnMENUinfostudent();
	afx_msg void OnMENUinputmarks();
	afx_msg void OnMENUmarkreport();
	afx_msg void OnMENUofficeinfo();
	afx_msg void OnMENUregbreakinfo();
	afx_msg void OnMENUstudentinfo();
	afx_msg void OnMENUsubjectinfo();
	afx_msg void OnMENUteacherinfo();
	afx_msg void OnMENUuser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTUDENTSYSDLG_H__CCE285FD_DAFC_41B6_A174_1A2D9E4A14EE__INCLUDED_)
